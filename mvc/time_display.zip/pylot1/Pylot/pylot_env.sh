#!/bin/bash

git clone -b stable https://github.com/Ketul-Patel/Pylot.git
source pylotVenv/bin/activate
pip install -r system/dependencies.txt
