alert("Whoa, ninjas page!");
